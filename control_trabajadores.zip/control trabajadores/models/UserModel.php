<?php
class User
{
    private $id;
    private $name;
    private $apellidos;
    private $DNI;
    private $email;
    private $telefono;
    private $password;
    private $rol;
    private $status;
    private $status_date;

    public function __construct($datos)
    {
        $this->id = $datos['id'];
        $this->name = $datos['name'];
        $this->apellidos = $datos['apellidos'];
        $this->DNI = $datos['DNI'];
        $this->email = $datos['email'];
        $this->telefono = $datos['telefono'];
        $this->password = $datos['password'];
        $this->rol = $datos['rol'];
        $this->status = $datos['status'];
        $this->status_date = $datos['status_date']; 
    }

    public function getId()
    {
        return $this->id;
    }

    public function getName()
    {
        return $this->name;
    }

    public function getApellidos()
    {
        return $this->apellidos;
    }

    public function getDNI()
    {
        return $this->DNI;
    }

    public function getEmail()
    {
        return $this->email;
    }

    public function getTelefono()
    {
        return $this->telefono;
    }

    public function getRol()
    {
        return $this->rol;
    }

    public function getStatus()
    {
        return $this->status;
    } 

    public function getStatusDate()
    {
        return $this->status_date;
    } 

}
?>
