<?php
class Job
{
    private $id;
    private $lugar;
    private $descripcion;
    private $fecha_salida;
    private $fecha_regreso;
    private $sueldo;
    private $open;


    public function __construct($datos)
    {
        $this->id = $datos['id'];
        $this->lugar = $datos['lugar'];
        $this->descripcion = $datos['descripcion'];
        $this->fecha_salida = $datos['fecha_salida'];
        $this->fecha_regreso = $datos['fecha_regreso'];
        $this->sueldo = $datos['sueldo'];
        $this->open = $datos['open'];
    }

    public function getId()
    {
        return $this->id;
    }

    public function getLugar()
    {
        return $this->lugar;
    }

    public function getDescripcion()
    {
        return $this->descripcion;
    }

    public function getFechaSalida()
    {
        return $this->fecha_salida;
    }

    public function getFechaRegreso()
    {
        return $this->fecha_regreso;
    }

    public function getSueldo()
    {
        return $this->sueldo;
    } 

    public function getOpen()
    {
        return $this->open;
    } 
}
?>
