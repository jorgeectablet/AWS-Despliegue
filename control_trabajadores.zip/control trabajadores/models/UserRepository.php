<?php
class UserRepository
{

    public static function addUser($u, $a, $d, $e, $t, $p)
    {
        echo "llama a la funcion adduser";
        $db = Conectar::conexion();
        $result = $db->query("INSERT INTO trabajadores VALUES ('NULL', '" . $u . "', '" .$a. "', '" . $d . "', '" . $e . "', '" . $t . "', '" . $p . "','0', '0', 'NULL')");
        return $db->insert_id;
    }

    public static function checkLogin($u, $p)
    {
        $db = Conectar::conexion();
        $result= $db->query("SELECT * FROM trabajadores WHERE name = '".$u."' AND password='".$p."'");
        if ($row = $result->fetch_assoc()) return new User($row);
        else return false;
    }

    public static function getUserId($id)
    {
        $db = Conectar::conexion();
        $usuarios = [];
        $result = $db->query("SELECT * FROM trabajadores WHERE id = '$id'");
        if ($datos = $result->fetch_assoc())
        {
            return new User($datos);
        }
    }

    public static function getUsuarios()
    {
        $db = Conectar::conexion();
        $result = $db->query("SELECT * FROM trabajadores");
        while ($datos = $result->fetch_assoc())
        {
            $usuarios[] = new User($datos);
        }
        return $usuarios;
    }
}
?>
