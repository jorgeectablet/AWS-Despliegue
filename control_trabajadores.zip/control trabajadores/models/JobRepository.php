<?php
class JobRepository 
{
    public static function getJobs()
    {
        $db = Conectar::conexion();
        $jobs = [];
        $result = $db->query("SELECT * FROM jobs");
        while ($datos = $result->fetch_assoc())
        {
            $jobs[] = new Job($datos);
        }
        return $jobs;
    }

    public static function addJob($l, $d, $fs, $fr, $s)
    {
        $db = Conectar::conexion();
        $result = $db->query("INSERT INTO jobs VALUES ('NULL', '" . $l . "', '" . $d . "', '" . $fs . "', '" . $fr . "', '" . $s . "', '1')");
        return $db->insert_id;
    }

    public static function mark_as_active()
    {
        $db = Conectar::conexion();
        $result = $db->query("UPDATE trabajadores SET status = 1 WHERE id = '" .$_SESSION['user']->getId(). "'");
        $result = $db->query("UPDATE trabajadores SET status_date = NOW() WHERE id = '" .$_SESSION['user']->getId(). "'");
        return $db->insert_id;
    }

    public static function mark_as_closed()
    {
        $db = Conectar::conexion();
        $result = $db->query("UPDATE trabajadores SET status = 0 WHERE id = '" .$_SESSION['user']->getId(). "'");
        $result = $db->query("UPDATE jobs SET open = 0 WHERE id = '".$_GET['id']."'");
        var_dump($_POST['id']);
        return $db->insert_id;
    }
}
?>
