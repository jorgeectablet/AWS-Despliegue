<?php

if (isset($_GET['subir']))
{ 
    if (isset($_POST['lugar']) && isset($_POST['descripcion']) && isset($_POST['fecha_salida']) && isset($_POST['fecha_regreso']) && isset($_POST['sueldo']))
    { 
        if (!JobRepository::addJob($_POST['lugar'], $_POST['descripcion'], $_POST['fecha_salida'], $_POST['fecha_regreso'], $_POST['sueldo'])) $error = "Fail adding job";
    }
}

if (isset($_GET['closed']))
{ 
    JobRepository::mark_as_closed();
}

if (isset($_GET['active']))
{ 
    JobRepository::mark_as_active();
}

if (isset($_GET['new']))
{
    $jobs = JobRepository::getJobs();
    $usuarios = UserRepository::getUsuarios();
    require_once ("views/newTrabajoView.phtml");
    die;
}

?>
