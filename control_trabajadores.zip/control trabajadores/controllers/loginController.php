<?php
if (isset($_GET['login']))
{

    if (isset($_POST['user']) && isset($_POST['password']))
    {;
        $db = Conectar::conexion();
        if (isset($_GET['log']))
        {
            $result = $db->query("SELECT * FROM trabajadores WHERE name = '" . $_POST['user'] . "'");
            if ($datos = $result->fetch_assoc())
            {
                
                if ($datos['password'] == ($_POST['password']))
                {
          
                    $_SESSION['user'] = new User($datos);
                    header('location: index.php');

                }
                else $error = "password incorrecta";
                require_once('views/loginView.phtml');
            }
        }
        if (isset($_GET['regis']))
        {
            UserRepository::addUser($_POST['user'], $_POST['apellidos'], $_POST['DNI'], $_POST['email'], $_POST['telefono'], $_POST['password']);
        }
    }
}

if (isset($_GET['logout']))
{
    session_destroy();
    header('location: index.php');

}

/*else $error = "User is not loged ";*/

require_once ("views/loginView.phtml");
die();
?>
