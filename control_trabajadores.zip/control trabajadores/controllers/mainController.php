<?php
//cargamos el modelo
require_once ('models/UserModel.php');
require_once ('models/UserRepository.php');
require_once ('models/JobModel.php');
require_once ('models/JobRepository.php');


session_start();

if (!isset($_SESSION['user']))
{
    $datos['id'] = 0;
    $datos['name'] = "";
    $_SESSION['user'] = new User($datos);
}

if (isset($_GET['login']))
{
    require_once ('controllers/loginController.php');
}

if (isset($_GET['producto']))
{ 
    require_once ('controllers/ProductoController.php');
}

if (isset($_GET['admin']))
{
    require_once ('controllers/adminController.php');
}

if (isset($_GET['job']))
{
    require_once ('controllers/jobController.php');
}

$jobs = JobRepository::getJobs();

// cargar la vista
require_once ('views/mainView.phtml');
?>
