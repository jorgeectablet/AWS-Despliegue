<?php

if (isset($_GET['save']))
{ 
    $db = Conectar::conexion();
    $result = $db->query("UPDATE trabajadores SET `name`='" . $_POST['user'] . "',`apellidos`='" . $_POST['apellidos'] . "',`DNI`='" . $_POST['DNI'] . "',`email`='" . $_POST['email'] . "',`telefono`='" . $_POST['telefono'] . "',`rol`='' WHERE id = '" . $_POST['id'] . "'");
    return $db->insert_id;
}

if (isset($_GET['new']))
{
    $usuarios = UserRepository::getUsuarios();
    require_once ("views/adminView.phtml");
    die;
}

?>
